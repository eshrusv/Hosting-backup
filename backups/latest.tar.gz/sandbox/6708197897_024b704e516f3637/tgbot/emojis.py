"""
Premium custom-emoji helper.

Important: a `custom_emoji_id` only renders as an animated Telegram
Premium emoji for RECIPIENTS who themselves have Premium — everyone
else just sees the plain fallback glyph. Telegram requires that
fallback character to actually be present in the message text; the
MessageEntity just tells Premium clients "render this span using
this custom emoji instead".
"""
from telegram import MessageEntity

# Fallback glyph used as the entity anchor / what non-Premium users see.
PLACEHOLDER = "⭐"

PREMIUM_EMOJI_IDS = [
    "6266866272848321043",
    "6267117038808870117",
    "6267225207560214192",
    "6266995104687330978",
    "6267152480878990865",
    "6265004494719816749",
    "5042050649248760772",
    "5042225965518816316",
    "5039623284056917259",
    "5039544445637231745",
    "5039727497143387500",
    "5042341817966658405",
    "5039539210072097557",
    "5041852827350074289",
    "5039665997506675838",
    "5039671744172917707",
    "5040025580758631490",
    "5039789890133296083",
    "5042290883949495533",
    "5039600026809009149",
]


def build_premium_text(parts):
    """
    parts: list of (text, emoji_index_or_None) tuples, in order.
    Returns (full_text, [MessageEntity, ...]) ready for
    bot.send_message(text=..., entities=...).

    Example:
        text, entities = build_premium_text([
            (" Welcome!", 0),
            ("\\n\\nPaste a link to begin ", 1),
        ])
        await update.message.reply_text(text, entities=entities)
    """
    text = ""
    entities = []
    for chunk, idx in parts:
        if idx is None:
            text += chunk
            continue
        start = len(text)
        text += PLACEHOLDER
        entities.append(
            MessageEntity(
                type=MessageEntity.CUSTOM_EMOJI,
                offset=start,
                length=len(PLACEHOLDER),
                custom_emoji_id=PREMIUM_EMOJI_IDS[idx % len(PREMIUM_EMOJI_IDS)],
            )
        )
        text += chunk
    return text, entities
