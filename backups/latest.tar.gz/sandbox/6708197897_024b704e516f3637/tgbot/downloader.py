import os
import re
import time

import yt_dlp

from config import DOWNLOAD_DIR, MAX_FILE_SIZE_MB

os.makedirs(DOWNLOAD_DIR, exist_ok=True)

URL_RE = re.compile(r"(https?://[^\s]+)")

# Just used to give a friendlier "detected" feel; the generic extractor
# in yt-dlp will still try any http(s) link that falls through.
SUPPORTED_HINTS = [
    "youtube.com", "youtu.be", "instagram.com", "tiktok.com",
    "facebook.com", "fb.watch", "twitter.com", "x.com",
    "pinterest.com", "reddit.com", "vimeo.com", "dailymotion.com",
]


def extract_url(text: str):
    """Return the first http(s) URL found in text, or None."""
    if not text:
        return None
    m = URL_RE.search(text)
    return m.group(1) if m else None


def looks_like_media_link(url: str) -> bool:
    return url.startswith("http")


def _progress_hook_factory(on_progress):
    last_edit = {"t": 0.0}

    def hook(d):
        if d.get("status") != "downloading" or on_progress is None:
            return
        now = time.time()
        if now - last_edit["t"] < 2.0:  # throttle to avoid Telegram flood limits
            return
        last_edit["t"] = now
        total = d.get("total_bytes") or d.get("total_bytes_estimate") or 0
        done = d.get("downloaded_bytes", 0)
        speed = d.get("speed") or 0
        pct = (done / total * 100) if total else 0
        on_progress(pct, done, total, speed)

    return hook


def download_media(url: str, on_progress=None):
    """
    Downloads the best-quality video under MAX_FILE_SIZE_MB using yt-dlp.
    Returns (local_file_path, title). Raises RuntimeError with a
    user-readable message on failure.
    """
    outtmpl = os.path.join(DOWNLOAD_DIR, "%(id)s.%(ext)s")

    ydl_opts = {
        "outtmpl": outtmpl,
        "format": (
            f"best[filesize<{MAX_FILE_SIZE_MB}M]/"
            f"bestvideo[filesize<{MAX_FILE_SIZE_MB}M]+bestaudio/best"
        ),
        "merge_output_format": "mp4",
        "noplaylist": True,
        "quiet": True,
        "no_warnings": True,
        "concurrent_fragment_downloads": 8,  # speeds up HLS/DASH downloads a lot
        "retries": 3,
        "fragment_retries": 3,
        # If aria2c is installed on the host, uncomment for even faster downloads:
        # "external_downloader": "aria2c",
        # "external_downloader_args": ["-x", "16", "-s", "16", "-k", "1M"],
    }

    if on_progress:
        ydl_opts["progress_hooks"] = [_progress_hook_factory(on_progress)]

    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=True)
            if "entries" in info:  # safety net, shouldn't trigger with noplaylist
                info = info["entries"][0]
            path = ydl.prepare_filename(info)
            if not os.path.exists(path):
                base, _ = os.path.splitext(path)
                for ext in (".mp4", ".mkv", ".webm"):
                    if os.path.exists(base + ext):
                        path = base + ext
                        break

            size_mb = os.path.getsize(path) / (1024 * 1024)
            if size_mb > MAX_FILE_SIZE_MB:
                os.remove(path)
                raise RuntimeError(
                    f"File is {size_mb:.0f}MB, over the {MAX_FILE_SIZE_MB}MB limit."
                )
            return path, info.get("title", "video")
    except yt_dlp.utils.DownloadError as e:
        raise RuntimeError(f"Couldn't download this link: {e}")
