import os

# ── Bot token ────────────────────────────────────────────────────────────
BOT_TOKEN = os.getenv("BOT_TOKEN", "8975479341:AAERBjyH3VIPabCsvrDnDRfSway6rcUrMx4")

# ── Branding ─────────────────────────────────────────────────────────────
OWNER_USERNAME = "@ZulqarPRO"
OWNER_MARK = f"Powered by {@ZulqarBRO}"

# ── Admins ───────────────────────────────────────────────────────────────
# Telegram numeric user IDs (NOT usernames). Get yours from @userinfobot.
ADMIN_IDS = [123456789]  # <-- replace with your real numeric Telegram ID(s)

# ── Inline buttons ───────────────────────────────────────────────────────
SUPPORT_URL = "https://t.me/ZulqarPRO"
CHANNEL_URL = "https://t.me/ZulqarPRO"

# ── Large file uploads ───────────────────────────────────────────────────
# The public Bot API only lets bots UPLOAD files up to 50MB. To send files
# up to 2GB you must run your own local Bot API server (see README.md) and
# point this at it, e.g. "http://localhost:8081/bot".
# Leave as None to use the standard 50MB-limited cloud API.
LOCAL_BOT_API_URL = os.getenv("LOCAL_BOT_API_URL")

# ── Download limits ──────────────────────────────────────────────────────
MIN_FILE_SIZE_MB = 1
MAX_FILE_SIZE_MB = 1000  # 1GB — only deliverable with LOCAL_BOT_API_URL set

DOWNLOAD_DIR = "downloads"
DB_PATH = "bot.db"
