from telegram import Update, InlineKeyboardMarkup, InlineKeyboardButton
from telegram.ext import ContextTypes

from config import SUPPORT_URL, CHANNEL_URL, OWNER_USERNAME
from emojis import build_premium_text
import database as db


def main_keyboard():
    return InlineKeyboardMarkup(
        [
            [
                InlineKeyboardButton("🆘 Support", url=SUPPORT_URL),
                InlineKeyboardButton("⬇️ Video Downloader", url=CHANNEL_URL),
            ],
        ]
    )


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    db.touch_user(user.id, user.username or "")

    text, entities = build_premium_text(
        [
            (" Welcome to the Video Downloader Bot", 0),
            (
                "\n\nSend me a link from YouTube, Instagram, TikTok, Facebook, "
                "Twitter/X, Pinterest, or almost anywhere else — I'll auto-detect "
                "it and send the video straight back to you.",
                None,
            ),
            ("\n\n⚡ Fast downloads · handles 1MB – 1GB files\n", None),
            (f"Owner: {OWNER_USERNAME}", 1),
        ]
    )

    await update.message.reply_text(text, entities=entities, reply_markup=main_keyboard())


async def help_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "Just paste a video link and I'll grab it for you automatically.\n\n"
        "/start — welcome message\n"
        "/help — this message\n"
        "/admin — admin panel (admins only)\n\n"
        f"Support: {SUPPORT_URL}",
        reply_markup=main_keyboard(),
    )
