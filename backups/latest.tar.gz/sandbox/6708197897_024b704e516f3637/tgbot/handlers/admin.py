from telegram import Update, InlineKeyboardMarkup, InlineKeyboardButton
from telegram.ext import ContextTypes

from config import ADMIN_IDS
import database as db


def is_admin(user_id: int) -> bool:
    return user_id in ADMIN_IDS


def admin_keyboard():
    return InlineKeyboardMarkup(
        [
            [InlineKeyboardButton("📊 Stats", callback_data="admin_stats")],
            [InlineKeyboardButton("📢 Broadcast", callback_data="admin_broadcast")],
            [
                InlineKeyboardButton("🚫 Ban user", callback_data="admin_ban"),
                InlineKeyboardButton("✅ Unban user", callback_data="admin_unban"),
            ],
        ]
    )


async def admin_panel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        await update.message.reply_text("🚫 You are not an admin.")
        return
    await update.message.reply_text("⚙️ Admin Panel", reply_markup=admin_keyboard())


async def admin_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    if not is_admin(query.from_user.id):
        await query.answer("Not authorized.", show_alert=True)
        return
    await query.answer()

    if query.data == "admin_stats":
        users = db.total_users()
        downloads = db.total_downloads()
        await query.edit_message_text(
            f"📊 Bot Stats\n\nUsers: {users}\nTotal downloads: {downloads}",
            reply_markup=admin_keyboard(),
        )
    elif query.data == "admin_broadcast":
        context.user_data["awaiting_broadcast"] = True
        await query.edit_message_text("📢 Send me the broadcast message text now.")
    elif query.data == "admin_ban":
        context.user_data["awaiting_ban"] = True
        await query.edit_message_text("🚫 Send the numeric user ID to ban.")
    elif query.data == "admin_unban":
        context.user_data["awaiting_unban"] = True
        await query.edit_message_text("✅ Send the numeric user ID to unban.")


async def admin_text_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> bool:
    """
    Handles the follow-up text after an admin taps Broadcast/Ban/Unban.
    Returns True if it consumed the message, False otherwise — callers
    should fall through to the normal link handler when this returns False.
    """
    if not is_admin(update.effective_user.id):
        return False

    if context.user_data.get("awaiting_broadcast"):
        context.user_data["awaiting_broadcast"] = False
        text = update.message.text
        sent, failed = 0, 0
        for uid in db.all_user_ids():
            try:
                await context.bot.send_message(uid, text)
                sent += 1
            except Exception:
                failed += 1
        await update.message.reply_text(f"📢 Broadcast done. Sent: {sent}, Failed: {failed}")
        return True

    if context.user_data.get("awaiting_ban"):
        context.user_data["awaiting_ban"] = False
        try:
            uid = int(update.message.text.strip())
            db.set_banned(uid, True)
            await update.message.reply_text(f"🚫 Banned {uid}.")
        except ValueError:
            await update.message.reply_text("Invalid user ID — send a number.")
        return True

    if context.user_data.get("awaiting_unban"):
        context.user_data["awaiting_unban"] = False
        try:
            uid = int(update.message.text.strip())
            db.set_banned(uid, False)
            await update.message.reply_text(f"✅ Unbanned {uid}.")
        except ValueError:
            await update.message.reply_text("Invalid user ID — send a number.")
        return True

    return False
