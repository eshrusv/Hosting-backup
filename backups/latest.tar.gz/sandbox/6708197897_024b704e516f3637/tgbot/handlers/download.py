import os
import asyncio
import logging
import concurrent.futures

from telegram import Update, InlineKeyboardMarkup, InlineKeyboardButton
from telegram.ext import ContextTypes

from config import SUPPORT_URL, CHANNEL_URL, OWNER_USERNAME
from downloader import extract_url, looks_like_media_link, download_media
import database as db

logger = logging.getLogger(__name__)

# Downloads are CPU/IO heavy and blocking (yt-dlp), so they run in a small
# thread pool instead of blocking the bot's asyncio event loop.
_executor = concurrent.futures.ThreadPoolExecutor(max_workers=4)


def result_keyboard():
    return InlineKeyboardMarkup(
        [
            [
                InlineKeyboardButton("🆘 Support", url=SUPPORT_URL),
                InlineKeyboardButton("⬇️ Downloader", url=CHANNEL_URL),
            ],
        ]
    )


async def _safe_edit(message, text):
    try:
        await message.edit_text(text)
    except Exception:
        pass  # message may be unchanged / rate-limited — never crash on a UI update


async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    db.touch_user(user.id, user.username or "")

    if db.is_banned(user.id):
        await update.message.reply_text("🚫 You're banned from using this bot.")
        return

    url = extract_url(update.message.text or "")
    if not url or not looks_like_media_link(url):
        await update.message.reply_text(
            "Send me a video link (YouTube, Instagram, TikTok, Facebook, "
            "Twitter/X, Pinterest, etc.) and I'll auto-detect and download it.",
            reply_markup=result_keyboard(),
        )
        return

    status = await update.message.reply_text("🔎 Link detected. Starting download… 0%")
    loop = asyncio.get_running_loop()
    last_pct = {"v": -10.0}

    def on_progress(pct, done, total, speed):
        if pct - last_pct["v"] < 5 and pct < 99:
            return
        last_pct["v"] = pct
        speed_mb = (speed or 0) / (1024 * 1024)
        text = f"⬇️ Downloading… {pct:.0f}%  ({speed_mb:.1f} MB/s)"
        asyncio.run_coroutine_threadsafe(_safe_edit(status, text), loop)

    try:
        path, title = await loop.run_in_executor(_executor, download_media, url, on_progress)
    except RuntimeError as e:
        await status.edit_text(f"❌ {e}")
        return
    except Exception:
        logger.exception("Unexpected download error for url=%s", url)
        await status.edit_text("❌ Something went wrong downloading that link. Please try another one.")
        return

    try:
        await status.edit_text("📤 Uploading to Telegram…")
        with open(path, "rb") as f:
            caption = f"🎬 {title}\n\nDownloaded via {OWNER_USERNAME}"
            await update.message.reply_video(
                video=f,
                caption=caption,
                reply_markup=result_keyboard(),
                supports_streaming=True,
                read_timeout=120,
                write_timeout=120,
                connect_timeout=60,
            )
        db.incr_download(user.id)
        await status.delete()
    except Exception:
        logger.exception("Upload failed for url=%s", url)
        await status.edit_text(
            "❌ Downloaded fine, but Telegram rejected the upload — this usually means "
            "the file is over the 50MB bot upload limit. See README.md for enabling "
            "large-file uploads (up to 2GB) via a local Bot API server."
        )
    finally:
        if os.path.exists(path):
            os.remove(path)
