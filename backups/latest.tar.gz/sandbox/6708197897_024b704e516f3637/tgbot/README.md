# Video Downloader Bot — @ZulqarPRO

Auto-detects video links (YouTube, Instagram, TikTok, Facebook, Twitter/X,
Pinterest, and most other sites yt-dlp supports), downloads them, and sends
them back in Telegram — with inline Support/Downloader buttons, an admin
panel, and a global error handler so the bot never crashes on bad input.

## 1. Install

```bash
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

You also need **ffmpeg** on the host (used by yt-dlp to merge video+audio):

```bash
# Debian/Ubuntu
sudo apt install ffmpeg
# macOS
brew install ffmpeg
```

## 2. Configure

Edit `config.py` or set environment variables:

- `BOT_TOKEN` — get one from [@BotFather](https://t.me/BotFather)
- `ADMIN_IDS` — your numeric Telegram user ID (get it from @userinfobot),
  *not* your @username
- `SUPPORT_URL` / `CHANNEL_URL` — the links shown on the inline buttons

## 3. Run

```bash
python main.py
```

Send the bot a video link. It auto-detects the link, downloads it, shows
live progress (%, speed), and uploads it back with Support/Downloader
buttons.

## 4. Admin panel

Any user ID in `ADMIN_IDS` can run `/admin` to get an inline panel with:

- **Stats** — total users, total downloads
- **Broadcast** — send a message to every non-banned user
- **Ban / Unban** — block a user ID from using the bot

## 5. Important: the 50MB upload limit

Telegram's **public** Bot API only lets bots *upload* files up to **50MB**,
regardless of what you set `MAX_FILE_SIZE_MB` to in `config.py`. Downloads
up to that limit work out of the box.

To actually deliver files up to **2GB** (matching your "1MB–1GB" requirement),
you need to run your own **local Bot API server**:

```bash
# Get api_id / api_hash from https://my.telegram.org
docker run -d -p 8081:8081 \
  -e TELEGRAM_API_ID=<your_api_id> \
  -e TELEGRAM_API_HASH=<your_api_hash> \
  -v telegram-bot-api-data:/var/lib/telegram-bot-api \
  aiogram/telegram-bot-api:latest
```

Then set:

```bash
export LOCAL_BOT_API_URL="http://localhost:8081/bot"
```

and restart the bot. No code changes needed — `main.py` already reads
`LOCAL_BOT_API_URL` and points the bot at your local server automatically.

## 6. Speed tuning

- `concurrent_fragment_downloads: 8` in `downloader.py` parallelizes
  HLS/DASH fragment downloads — the biggest speed win for most sites.
- For an extra boost, install **aria2c** (`sudo apt install aria2`) and
  uncomment the `external_downloader` lines in `downloader.py`.
- Progress-bar edits are throttled to once every ~2 seconds so large,
  fast downloads don't hit Telegram's message-edit rate limits.

## 7. Premium emoji

`emojis.py` holds your 20 premium `custom_emoji_id`s and a
`build_premium_text()` helper that builds a `(text, entities)` pair for
`reply_text(text=..., entities=...)`. These render as animated Premium
emoji **only for recipients who have Telegram Premium themselves** —
everyone else sees the plain ⭐ fallback glyph. That's a Telegram Bot API
rule, not a bug: there's no way to force a non-Premium client to render a
Premium emoji.

## 8. A note on scope

This bot uses [yt-dlp](https://github.com/yt-dlp/yt-dlp), which supports
downloading from many sites' publicly accessible pages. Some platforms'
terms of service restrict downloading content outside their own apps, and
copyright still applies to whatever gets downloaded — that's on however
you and your users end up using it, same as any other yt-dlp-based tool.

## File structure

```
tgbot/
├── main.py            # entrypoint, wiring, global error handler
├── config.py           # token, admins, links, limits
├── database.py          # SQLite: users, downloads, bans
├── downloader.py        # link detection + yt-dlp download logic
├── emojis.py             # premium custom emoji helper
├── handlers/
│   ├── start.py          # /start, /help
│   ├── download.py       # link auto-detect → download → upload
│   └── admin.py           # /admin panel: stats/broadcast/ban
└── requirements.txt
```
