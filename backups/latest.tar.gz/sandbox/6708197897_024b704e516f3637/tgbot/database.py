import sqlite3
import threading
import time

from config import DB_PATH

_lock = threading.Lock()


def _conn():
    return sqlite3.connect(DB_PATH, check_same_thread=False)


def init_db():
    with _lock, _conn() as c:
        c.execute(
            """
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY,
                username TEXT,
                first_seen INTEGER,
                last_seen INTEGER,
                downloads INTEGER DEFAULT 0,
                banned INTEGER DEFAULT 0
            )
            """
        )


def touch_user(user_id: int, username: str):
    now = int(time.time())
    with _lock, _conn() as c:
        c.execute(
            """
            INSERT INTO users (user_id, username, first_seen, last_seen)
            VALUES (?, ?, ?, ?)
            ON CONFLICT(user_id) DO UPDATE SET
                username=excluded.username,
                last_seen=excluded.last_seen
            """,
            (user_id, username, now, now),
        )


def is_banned(user_id: int) -> bool:
    with _lock, _conn() as c:
        row = c.execute("SELECT banned FROM users WHERE user_id=?", (user_id,)).fetchone()
        return bool(row and row[0])


def set_banned(user_id: int, banned: bool = True):
    with _lock, _conn() as c:
        c.execute("UPDATE users SET banned=? WHERE user_id=?", (1 if banned else 0, user_id))


def incr_download(user_id: int):
    with _lock, _conn() as c:
        c.execute("UPDATE users SET downloads = downloads + 1 WHERE user_id=?", (user_id,))


def total_users() -> int:
    with _lock, _conn() as c:
        return c.execute("SELECT COUNT(*) FROM users").fetchone()[0]


def total_downloads() -> int:
    with _lock, _conn() as c:
        row = c.execute("SELECT SUM(downloads) FROM users").fetchone()
        return row[0] or 0


def all_user_ids():
    with _lock, _conn() as c:
        return [r[0] for r in c.execute("SELECT user_id FROM users WHERE banned=0").fetchall()]
