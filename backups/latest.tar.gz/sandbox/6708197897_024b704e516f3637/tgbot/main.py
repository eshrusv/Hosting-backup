import logging

from telegram import Update
from telegram.ext import (
    Application,
    ApplicationBuilder,
    CommandHandler,
    MessageHandler,
    CallbackQueryHandler,
    ContextTypes,
    filters,
)

from config import BOT_TOKEN, LOCAL_BOT_API_URL
import database as db
from handlers.start import start, help_cmd
from handlers.download import handle_message
from handlers.admin import admin_panel, admin_callback, admin_text_input

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)


async def on_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Routes plain text: admin follow-ups (broadcast/ban/unban) first,
    then falls through to normal link auto-detection."""
    handled = await admin_text_input(update, context)
    if handled:
        return
    await handle_message(update, context)


async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE):
    """Global error handler — logs everything, never lets the bot crash,
    and gives the user a clean message instead of silence."""
    logger.error("Update %s caused error: %s", update, context.error, exc_info=context.error)
    try:
        if isinstance(update, Update) and update.effective_message:
            await update.effective_message.reply_text(
                "⚠️ An unexpected error occurred. Please try again in a moment."
            )
    except Exception:
        pass


def build_app() -> Application:
    builder = ApplicationBuilder().token(BOT_TOKEN)
    if LOCAL_BOT_API_URL:
        builder = builder.base_url(LOCAL_BOT_API_URL)
    app = builder.build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_cmd))
    app.add_handler(CommandHandler("admin", admin_panel))
    app.add_handler(CallbackQueryHandler(admin_callback, pattern="^admin_"))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, on_text))
    app.add_error_handler(error_handler)
    return app


def main():
    if BOT_TOKEN == "8975479341:AAERBjyH3VIPabCsvrDnDRfSway6rcUrMx4":
        raise SystemExit(
            "Set BOT_TOKEN (env var or in config.py) before starting the bot. "
            "Get one from @BotFather."
        )
    db.init_db()
    app = build_app()
    logger.info("Bot starting…")
    app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
